
//Desarrolla un programa que dado el día y mes de nacimiento te indique cuál es tu signo del zodiaco.

package edu.alonso.tema2;

import java.util.Scanner;

public class SignoZodiaco {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Dime en que mes naciste del 1 al 12:");
		int mes = input.nextInt();
		System.out.print("Dime el dia que naciste:");
		int dia = input.nextInt();
		
		if(mes==1||mes==3||mes==5||mes==7||mes==8||mes==10||mes==12) {
			if (dia>31) {
				System.out.println("Introduce una fecha valida");
				System.exit(0);
			}
		}

		if(mes==4||mes==6||mes==9||mes==11) {
			if (dia>30) {
				System.out.println("Introduce una fecha valida");
				System.exit(0);
			}
		}
		if(mes==2) {
			if (dia>29) {
				System.out.println("Introduce una fecha valida");
				System.exit(0);
			}
		}
		if(mes>12||mes<1) {
			System.out.println("Eres bobo o que");
		}
		switch (mes) {
		case 1:
			if (dia>=20) {
				System.out.println("Eres Acuario");
				break;
			}else {
				System.out.println("Eres Capricornio");
				break;
			}
		case 2:
			if (dia>=19) {
				System.out.println("Eres Piscis");
				break;
			}else {
				System.out.println("Eres Acuario");
				break;
			}
		case 3:
			if (dia>=21) {
				System.out.println("Eres Aries");
				break;
			}else {
				System.out.println("Eres Piscis");
				break;
			}
		case 4:
			if (dia>=20) {
				System.out.println("Eres Tauro");
				break;
			}else {
				System.out.println("Eres Aries");
				break;
			}
		case 5:
			if (dia>=21) {
				System.out.println("Eres Géminis");
				break;
			}else {
				System.out.println("Eres Tauro");
				break;
			}
		case 6:
			if (dia>=21) {
				System.out.println("Eres Cancer");
				break;
			}else {
				System.out.println("Eres Géminis");
				break;
			}
		case 7:
			if (dia>=23) {
				System.out.println("Eres Leo");
				break;
			}else {
				System.out.println("Eres Cancer");
				break;
			}
		case 8:
			if (dia>=23) {
				System.out.println("Eres Virgo");
				break;
			}else {
				System.out.println("Eres Leo");
				break;
			}
		case 9:
			if (dia>=23) {
				System.out.println("Eres Libra");
				break;
			}else {
				System.out.println("Eres Virgo");
				break;
			}
		case 10:
			if (dia>=23) {
				System.out.println("Eres Escorpio");
				break;
			}else {
				System.out.println("Eres Libra");
				break;
			}
		case 11:
			if (dia>=22) {
				System.out.println("Eres Sagitario");
				break;
			}else {
				System.out.println("Eres Escorpio");
				break;
			}
		case 12:
			if (dia>=22) {
				System.out.println("Eres Capricornio");
				break;
			}else {
				System.out.println("Eres Sagitario");
				break;
			}
		}	
	}		
}
